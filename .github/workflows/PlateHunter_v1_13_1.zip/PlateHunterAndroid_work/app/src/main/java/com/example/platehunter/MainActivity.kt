package com.example.platehunter

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.location.Geocoder
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.net.Uri
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaRecorder
import android.media.ToneGenerator
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.os.VibrationEffect
import android.os.Vibrator
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.*
import androidx.core.app.ActivityCompat
import androidx.core.content.FileProvider
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import okhttp3.OkHttpClient
import okhttp3.Request
import kotlin.math.abs
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private val BG = 0xFF0E141B.toInt()
    private val CARD = 0xFF17202B.toInt()
    private val STROKE = 0xFF243140.toInt()
    private val FIELD = 0xFF0F161D.toInt()
    private val TEAL = 0xFF4CC3B0.toInt()
    private val RED = 0xFFFF6B6B.toInt()
    private val TEXT = 0xFFE8EEF4.toInt()
    private val MUTED = 0xFF8A97A6.toInt()
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private lateinit var status: TextView
    private lateinit var spoken: TextView
    private lateinit var recordsBox: LinearLayout
    private lateinit var listenButton: Button
    private lateinit var nameEdit: EditText
    private lateinit var platesCount: TextView
    private lateinit var wantedCount: TextView
    private lateinit var wantedHeader: TextView
    private lateinit var lastPlateView: TextView
    private val letterBoxes = mutableListOf<TextView>()
    private val digitBoxes = mutableListOf<TextView>()

    private var sr: SpeechRecognizer? = null
    private var listening = false
    private val records = mutableListOf<JSONObject>()
    private val wanted = mutableSetOf<String>()
    private val fmt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
    private var cloudSpeech: CloudSpeech? = null
    private var liveSpeech: GeminiLiveSpeech? = null
    private var chatSpeech: ChatGptLiveSpeech? = null
    private var lastLoc: Location? = null
    private var tts: TextToSpeech? = null
    private val wantedInfo = HashMap<String, MutableList<List<Pair<String, String>>>>()
    private val districtCache = java.util.concurrent.ConcurrentHashMap<String, String>()
    private val geoExecutor = Executors.newSingleThreadExecutor()
    private val http by lazy { OkHttpClient.Builder().callTimeout(10, TimeUnit.SECONDS).build() }
    private lateinit var matchCard: LinearLayout
    private lateinit var matchTitle: TextView
    private lateinit var matchBody: TextView
    private var ttsReady = false
    private val assembler = PlateAssembler()
    private var utterStamp: PlateAssembler.Stamp? = null
    // plates found while still speaking are saved at once; these keep their ids/stamps until the final text arrives
    private val interimIds = ArrayList<Long>()
    private val interimStamps = ArrayList<PlateAssembler.Stamp>()
    private val deletedIds = HashSet<Long>()
    private var lastUpsertMs = 0L
    // ---- مربعات الحي: a rectangle split into rows x cols named cells ----
    private class ZoneGrid(val n: Double, val s: Double, val w: Double, val e: Double, val rows: Int, val cols: Int, val names: MutableList<String>)
    private var zoneGrid: ZoneGrid? = null
    // ---- مناطق بالأسماء: named rectangles (street to street); checked before the grid ----
    /** A named area bounded by 3-4 corner points (lat, lon) taken in order around its edge. */
    private class CustomZone(var name: String, val pts: List<Pair<Double, Double>>) {
        fun contains(lat: Double, lon: Double): Boolean {
            var inside = false
            var j = pts.size - 1
            for (i in pts.indices) {
                val yi = pts[i].first; val xi = pts[i].second; val yj = pts[j].first; val xj = pts[j].second
                if ((yi > lat) != (yj > lat) && lon < (xj - xi) * (lat - yi) / (yj - yi) + xi) inside = !inside
                j = i
            }
            return inside
        }
    }
    private val customZones = mutableListOf<CustomZone>()
    private lateinit var customListBox: LinearLayout
    private lateinit var customNowView: TextView
    private lateinit var zoneListBox: LinearLayout
    private lateinit var zoneNowView: TextView
    private var idCounter = 0L
    private val prefs by lazy { getSharedPreferences("platehunter_settings", MODE_PRIVATE) }
    private fun mode(): Int = prefs.getInt("mode", 0).coerceIn(0, 4)

    private val locListener = object : LocationListener {
        override fun onLocationChanged(location: Location) {
            lastLoc = location
            if (recording) recTrack.add(doubleArrayOf(System.currentTimeMillis().toDouble(), location.latitude, location.longitude, location.accuracy.toDouble()))
        }
        override fun onProviderEnabled(provider: String) {}
        override fun onProviderDisabled(provider: String) {}
        override fun onStatusChanged(provider: String?, st: Int, extras: Bundle?) {}
    }

    // ---------- UI helpers ----------
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun bg(color: Int, radius: Int, stroke: Int? = null) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radius).toFloat(); if (stroke != null) setStroke(dp(1), stroke)
    }
    private fun tv(text: String, size: Float = 15f, color: Int = TEXT, bold: Boolean = false) = TextView(this).apply {
        this.text = text; textSize = size; setTextColor(color); if (bold) setTypeface(typeface, Typeface.BOLD)
    }
    private fun card() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; background = bg(CARD, 20, STROKE)
        setPadding(dp(16), dp(14), dp(16), dp(14))
        layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { setMargins(0, 0, 0, dp(12)) }
    }
    private fun btn(text: String, fill: Int, color: Int, size: Float = 16f) = Button(this).apply {
        this.text = text; setTextColor(color); background = bg(fill, 14); isAllCaps = false; textSize = size
        setTypeface(typeface, Typeface.BOLD)
    }
    private fun edit(hint: String) = EditText(this).apply {
        this.hint = hint; setHintTextColor(MUTED); setTextColor(TEXT); background = bg(FIELD, 14, STROKE)
        setPadding(dp(14), dp(12), dp(14), dp(12)); textSize = 16f; gravity = Gravity.START or Gravity.CENTER_VERTICAL
        setSingleLine(true)
    }
    private fun lp(w: Int = MATCH, h: Int = WRAP, top: Int = 0) = LinearLayout.LayoutParams(w, h).apply { topMargin = dp(top) }
    private val openState = HashMap<TextView, Boolean>()
    private fun setTitle(h: TextView, title: String) {
        h.tag = title
        h.text = (if (openState[h] == true) "▼ " else "◄ ") + title
    }
    private fun collapsible(title: String, body: View): Pair<LinearLayout, TextView> {
        val c = card(); val h = tv("", 18f, TEXT, true)
        body.visibility = View.GONE; setTitle(h, title)
        h.setOnClickListener {
            val open = body.visibility != View.VISIBLE
            body.visibility = if (open) View.VISIBLE else View.GONE
            openState[h] = open; setTitle(h, h.tag as String)
        }
        c.addView(h); c.addView(body, lp(top = 10))
        return Pair(c, h)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = BG; window.navigationBarColor = BG
        ui()
        load()
        tts = TextToSpeech(this) { st ->
            if (st == TextToSpeech.SUCCESS) {
                val r = tts?.setLanguage(Locale("ar"))
                ttsReady = r != null && r >= 0
                tts?.setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            }
        }
        val missing = arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.ACCESS_FINE_LOCATION)
            .filter { ActivityCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) ActivityCompat.requestPermissions(this, missing.toTypedArray(), 4)
        render()
        refreshPending()
    }

    override fun onResume() { super.onResume(); startLocation() }
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        startLocation()
    }

    // ---------- Screen ----------
    private fun ui() {
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(40), dp(14), dp(24)) }

        // Recorder name + date
        val head = card()
        val headRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        nameEdit = edit("اسم المسجِّل").apply {
            setText(prefs.getString("recorder", "")); inputType = InputType.TYPE_CLASS_TEXT
            addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) { prefs.edit().putString("recorder", s.toString()).apply() }
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            })
        }
        headRow.addView(nameEdit, LinearLayout.LayoutParams(0, WRAP, 1f))
        headRow.addView(tv(SimpleDateFormat("dd-MM-yyyy", Locale.US).format(Date()), 22f, TEXT, true).apply { setPadding(dp(16), 0, dp(4), 0) })
        head.addView(headRow); content.addView(head)

        // Counters + plate boxes + listen button
        val main = card()
        val counters = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun counter(label: String, color: Int): TextView {
            val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
            val num = tv("0", 44f, color, true).apply { gravity = Gravity.CENTER }
            col.addView(num); col.addView(tv(label, 20f, MUTED).apply { gravity = Gravity.CENTER })
            counters.addView(col, LinearLayout.LayoutParams(0, WRAP, 1f)); return num
        }
        platesCount = counter("لوحات", TEXT)
        wantedCount = counter("مطلوبة", RED)
        main.addView(counters)

        val boxesRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun box(list: MutableList<TextView>) {
            val b = TextView(this).apply {
                gravity = Gravity.CENTER; textSize = 24f; setTextColor(TEXT); background = bg(FIELD, 14, STROKE)
            }
            list.add(b); boxesRow.addView(b, LinearLayout.LayoutParams(0, dp(56), 1f).apply { setMargins(dp(3), 0, dp(3), 0) })
        }
        repeat(3) { box(letterBoxes) }
        boxesRow.addView(View(this), LinearLayout.LayoutParams(0, dp(1), 0.5f))
        repeat(4) { box(digitBoxes) }
        main.addView(boxesRow, lp(top = 16))
        showPlate(null)

        status = tv("متوقف", 16f, MUTED).apply { gravity = Gravity.CENTER }
        spoken = tv("", 14f, MUTED).apply { gravity = Gravity.CENTER }
        main.addView(status, lp(top = 12)); main.addView(spoken, lp(top = 4))
        listenButton = btn("ابدأ الاستماع 🎤", TEAL, 0xFF06201C.toInt(), 22f).apply {
            setOnClickListener { if (listening) stopListening() else startListening() }
        }
        main.addView(listenButton, lp(h = dp(64), top = 16))
        content.addView(main)

        // Street recording (Gemini)
        val sc = card()
        sc.addView(tv("تسجيل شارع بـ Gemini", 18f, TEXT, true))
        sc.addView(tv("سجّل الشارع صوتيًا (اسم الشارع ثم اللوحات وأنواعها). يأخذ التطبيق موقعك لحظة البدء ولحظة الإنهاء ويتتبع مسارك، ثم يرسل التسجيل لـ Gemini، وتأخذ كل لوحة موقعها على المسار.", 13f, MUTED))
        streetBtn = btn("⏺ ابدأ تسجيل شارع", 0xFF3A1D22.toInt(), RED, 18f).apply {
            setOnClickListener { if (recording) stopStreetRecording() else startStreetRecording() }
        }
        sc.addView(streetBtn, lp(h = dp(60), top = 10))
        recStatus = tv("", 14f, MUTED).apply { gravity = Gravity.CENTER }
        sc.addView(recStatus, lp(top = 8))
        pendingBtn = btn("📤 إرسال التسجيلات المعلّقة", 0xFF1D4A42.toInt(), TEAL, 15f).apply {
            visibility = View.GONE
            setOnClickListener { pendingIds().forEach { sendPending(it) } }
        }
        sc.addView(pendingBtn, lp(h = dp(48), top = 8))
        content.addView(sc)

        // Last plate
        val last = card()
        last.addView(tv("آخر لوحة", 15f, MUTED))
        lastPlateView = tv("—", 34f, TEAL, true).apply { gravity = Gravity.CENTER; setPadding(0, dp(10), 0, dp(10)) }
        last.addView(lastPlateView)
        last.addView(btn("⌫ مسح آخر حرف أو رقم", 0xFF1D4A42.toInt(), TEAL, 15f).apply { setOnClickListener { backspace() } }, lp(h = dp(48), top = 4))
        val lastBtns = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        lastBtns.addView(btn("✕ حذف آخر لوحة", 0xFF3A1D22.toInt(), RED, 15f).apply {
            setOnClickListener { records.lastOrNull()?.let { deleteRecord(it) } ?: toast("السجل فارغ") }
        }, LinearLayout.LayoutParams(0, dp(48), 1f).apply { topMargin = dp(8) })
        lastBtns.addView(btn("↩ مسح المربعات", 0xFF1F2A36.toInt(), TEXT, 15f).apply {
            setOnClickListener { assembler.reset(); utterStamp = null; showPlate(null); spoken.text = ""; setStatus("تم مسح المربعات") }
        }, LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginStart = dp(8); topMargin = dp(8) })
        last.addView(lastBtns)
        content.addView(last)

        matchCard = card().apply { background = bg(0xFF2A1B20.toInt(), 20, RED); visibility = View.GONE }
        matchTitle = tv("", 20f, RED, true)
        matchBody = tv("", 16f, TEXT).apply { setPadding(0, dp(8), 0, dp(8)); setTextIsSelectable(true) }
        matchCard.addView(matchTitle); matchCard.addView(matchBody)
        matchCard.addView(btn("إخفاء", 0xFF3A1D22.toInt(), RED, 14f).apply { setOnClickListener { matchCard.visibility = View.GONE } }, lp(h = dp(44)))
        content.addView(matchCard)

        // Manual entry
        val manual = card()
        val manualRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val input = edit("إدخال يدوي: س ب ح 7831 تاكسي")
        manualRow.addView(input, LinearLayout.LayoutParams(0, WRAP, 1f))
        manualRow.addView(btn("إضافة", 0xFF1D4A42.toInt(), TEAL).apply {
            setOnClickListener {
                val before = records.size
                val tmp = PlateAssembler(); val snk = RecSink("manual")
                tmp.feed(input.text.toString(), currentStamp(), snk); tmp.flush(snk)
                if (records.size == before) toast("تعذر فهم اللوحة؛ اكتب مثل: س ر ط 7520 تاكسي") else input.setText("")
            }
        }, LinearLayout.LayoutParams(WRAP, dp(52)).apply { marginStart = dp(10) })
        manual.addView(manualRow); content.addView(manual)

        // Wanted list
        val wantedBody = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        wantedBody.addView(tv("استورد ملف Excel (XLSX) أو CSV فيه عمود اللوحات.", 13f, MUTED))
        wantedBody.addView(Switch(this).apply {
            text = "🔔 صوت وتنبيه عند اللوحة المطلوبة"; setTextColor(TEXT); textSize = 15f
            isChecked = prefs.getBoolean("alert_sound", true)
            setOnCheckedChangeListener { _, c -> prefs.edit().putBoolean("alert_sound", c).apply() }
        }, lp(top = 10))
        wantedBody.addView(btn("استيراد المطلوبين من Excel أو CSV", 0xFF1D4A42.toInt(), TEAL, 15f).apply {
            setOnClickListener {
                val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
                    putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("text/csv", "text/plain", "application/vnd.ms-excel", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"))
                }
                startActivityForResult(i, 10)
            }
        }, lp(top = 8))
        wantedBody.addView(btn("مسح قائمة المطلوبين", 0xFF3A1D22.toInt(), RED, 15f).apply {
            setOnClickListener {
                AlertDialog.Builder(this@MainActivity).setMessage("مسح قائمة المطلوبين؟")
                    .setPositiveButton("مسح") { _, _ ->
                        wanted.clear(); wantedInfo.clear(); saveWanted()
                        records.forEach { it.put("matched", false) }; persist(); render()
                    }.setNegativeButton("إلغاء", null).show()
            }
        }, lp(top = 8))
        val (wantedCard, wh) = collapsible("قائمة المطلوبين (0)", wantedBody)
        wantedHeader = wh; content.addView(wantedCard)

        // Speech engine
        val engineBody = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val modeNames = listOf("محلي من أندرويد (قد يحتاج إنترنت)", "Deepgram مباشر", "Deepgram + Gemini عند الحاجة", "Gemini Live مباشر", "ChatGPT Live مباشر")
        val group = RadioGroup(this).apply { orientation = RadioGroup.VERTICAL }
        modeNames.forEachIndexed { i, n ->
            group.addView(RadioButton(this).apply { id = 100 + i; text = n; setTextColor(TEXT); textSize = 16f; isChecked = i == mode() })
        }
        group.setOnCheckedChangeListener { _, id -> prefs.edit().putInt("mode", id - 100).apply() }
        engineBody.addView(group)
        engineBody.addView(Switch(this).apply {
            text = "Gemini Live: اعتمد النص المؤقت لو اختلفت الحروف في النهائي"; setTextColor(TEXT); textSize = 14f
            isChecked = prefs.getBoolean("g_prefer_interim", true)
            setOnCheckedChangeListener { _, c -> prefs.edit().putBoolean("g_prefer_interim", c).apply() }
        }, lp(top = 10))
        engineBody.addView(btn("⚙️ مفاتيح Deepgram وGemini وOpenAI", 0xFF1D4A42.toInt(), TEAL, 15f).apply { setOnClickListener { showApiSettings() } }, lp(top = 8))
        content.addView(collapsible("محرك التعرف على الكلام", engineBody).first)

        // Teach letters
        content.addView(collapsible("تعليم المايك الحروف", mapEditor("letter_map",
            "لو المايك يسمع الحرف بكلمة مختلفة، علّمه: اكتب الكلمة كما يسمعها والحرف المقصود.",
            "الكلمة المسموعة (مثل: سن)", "الحرف (مثل: س)", true) { PlateParser.extraLetters = it }).first)

        // Word corrections
        content.addView(collapsible("تصحيح الكلمات", mapEditor("corr_map",
            "استبدل كلمة يخطئ فيها التفريغ بالكلمة الصحيحة قبل استخراج اللوحة.",
            "الكلمة الخاطئة", "الكلمة الصحيحة", false) { PlateParser.corrections = it }).first)

        // Named zones (street to street)
        content.addView(collapsible("مناطق بالأسماء (من شارع لشارع)", customZonesBody()).first)

        // Zones
        content.addView(collapsible("مربعات الحي", zonesBody()).first)

        // Log
        val log = card()
        val logHead = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        logHead.addView(tv("السجل", 20f, TEXT, true), LinearLayout.LayoutParams(0, WRAP, 1f))
        logHead.addView(btn("Excel 📥", 0xFF1D4A42.toInt(), TEAL, 15f).apply { setOnClickListener { export() } }, LinearLayout.LayoutParams(WRAP, dp(48)))
        logHead.addView(btn("🗑️ مسح السجل", 0xFF3A1D22.toInt(), RED, 15f).apply {
            setOnClickListener {
                AlertDialog.Builder(this@MainActivity).setMessage("مسح كل السجل؟ لا يمكن التراجع.")
                    .setPositiveButton("مسح") { _, _ -> records.clear(); assembler.reset(); persist(); render(); showPlate(null); lastPlateView.text = "—" }
                    .setNegativeButton("إلغاء", null).show()
            }
        }, LinearLayout.LayoutParams(WRAP, dp(48)).apply { marginStart = dp(8) })
        log.addView(logHead)
        undoBtn = btn("↩ تراجع", 0xFF1F2A36.toInt(), TEXT, 14f).apply {
            visibility = View.GONE
            setOnClickListener {
                lastDeleted?.let { deletedIds.remove(it.optLong("id")); records.add(it); records.sortBy { x -> x.optLong("epoch") }; persist(); render() }
                lastDeleted = null; visibility = View.GONE
            }
        }
        log.addView(undoBtn, lp(h = dp(44), top = 8))
        log.addView(tv("✕ يحذف اللوحة كلها، واضغط على رقم اللوحة لتصحيحها", 12f, MUTED), lp(top = 8))
        log.addView(row("اللوحة", "النوع", "الحالة", "الوقت", "الموقع", true, MUTED, null, null), lp(top = 12))
        recordsBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        log.addView(recordsBox)
        content.addView(log)

        setContentView(ScrollView(this).apply {
            setBackgroundColor(BG); layoutDirection = View.LAYOUT_DIRECTION_RTL; isFillViewport = true
            addView(content)
        })
    }

    private fun row(plate: String, type: String, st: String, time: String, loc: String, header: Boolean, stColor: Int,
                    onLoc: (() -> Unit)?, onDel: (() -> Unit)?, onEdit: (() -> Unit)? = null, onStatus: (() -> Unit)? = null): LinearLayout {
        val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(6), 0, dp(6)) }
        fun cell(t: String, w: Float, col: Int, bold: Boolean = false): TextView =
            tv(t, 13f, col, bold).apply { gravity = Gravity.START }.also { r.addView(it, LinearLayout.LayoutParams(0, WRAP, w)) }
        val base = if (header) MUTED else TEXT
        val d = cell(if (onDel != null) "✕" else "", 0.5f, RED, true)
        d.textSize = 20f
        if (onDel != null) { d.setPadding(0, dp(8), 0, dp(8)); d.setOnClickListener { onDel() } }
        val pc = cell(plate, 1.4f, base, !header)
        if (onEdit != null) { pc.setPadding(0, dp(8), 0, dp(8)); pc.setOnClickListener { onEdit() } }
        cell(type, 0.8f, base)
        val sc = cell(st, 1f, if (header) MUTED else stColor, onStatus != null)
        if (onStatus != null) { sc.setPadding(0, dp(8), 0, dp(8)); sc.setOnClickListener { onStatus() } }
        cell(time, 1f, base)
        val l = cell(loc, 1.3f, if (onLoc != null) TEAL else base, onLoc != null)
        if (onLoc != null) { l.setPadding(0, dp(8), 0, dp(8)); l.setOnClickListener { onLoc() } }
        return r
    }

    private fun showPlate(p: String?) = showDraft(p?.take(3).orEmpty(), p?.drop(3).orEmpty())

    private fun showDraft(letters: String, digits: String) {
        letterBoxes.forEachIndexed { i, b -> b.text = letters.getOrNull(i)?.toString() ?: "" }
        digitBoxes.forEachIndexed { i, b -> b.text = digits.getOrNull(i)?.toString() ?: "•" }
    }

    private fun mapEditor(prefKey: String, desc: String, hintFrom: String, hintTo: String, singleLetter: Boolean, onChange: (Map<String, String>) -> Unit): LinearLayout {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        box.addView(tv(desc, 13f, MUTED))
        val from = edit(hintFrom); val to = edit(hintTo)
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        fun read(): MutableMap<String, String> {
            val m = linkedMapOf<String, String>()
            try { val o = JSONObject(prefs.getString(prefKey, "{}") ?: "{}"); o.keys().forEach { m[it] = o.getString(it) } } catch (_: Exception) {}
            return m
        }
        fun write(m: Map<String, String>) { prefs.edit().putString(prefKey, JSONObject(m as Map<*, *>).toString()).apply() }
        fun refresh() {
            val m = read(); onChange(m); list.removeAllViews()
            m.forEach { (k, v) ->
                list.addView(tv("$k  ←  $v      ✕", 15f, TEXT).apply {
                    setPadding(0, dp(8), 0, dp(8))
                    setOnClickListener { val mm = read(); mm.remove(k); write(mm); refresh() }
                })
            }
        }
        box.addView(from, lp(top = 8)); box.addView(to, lp(top = 8))
        box.addView(btn("إضافة", 0xFF1D4A42.toInt(), TEAL, 15f).apply {
            setOnClickListener {
                val k = from.text.toString().trim(); val v = to.text.toString().trim()
                if (k.isBlank() || v.isBlank()) { toast("اكتب الحقلين"); return@setOnClickListener }
                if (singleLetter && !(v.length == 1 && v[0] in '\u0621'..'\u064A')) { toast("اكتب حرفًا عربيًا واحدًا"); return@setOnClickListener }
                val m = read(); m[k] = v; write(m); from.setText(""); to.setText(""); refresh()
            }
        }, lp(top = 8))
        box.addView(list, lp(top = 8))
        refresh()
        return box
    }

    // ---------- Listening ----------
    private fun setListeningUi(on: Boolean) {
        listening = on
        listenButton.text = if (on) "⏹ إيقاف الاستماع" else "ابدأ الاستماع 🎤"
        listenButton.background = bg(if (on) RED else TEAL, 14)
        if (on) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }
    private fun setStatus(s: String, color: Int = MUTED) { status.text = s; status.setTextColor(color) }

    private fun hasMic() = ActivityCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun startListening() {
        if (recording) { toast("أنهِ تسجيل الشارع أولًا"); return }
        if (!hasMic()) { ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 4); return }
        when (mode()) {
            3 -> {
                val gk = prefs.getString("gemini_key", "").orEmpty()
                if (gk.isBlank()) { showApiSettings(); toast("أدخل مفتاح Gemini أولًا"); return }
                setListeningUi(true); setStatus("جاري الاتصال بـ Gemini Live…")
                liveSpeech = GeminiLiveSpeech({ transcript, isFinal -> runOnUiThread { if (isFinal) onGeminiFinal(transcript) else { gInterim = transcript; onTranscript(transcript, false, "gemini-live") } } },
                    { message -> runOnUiThread {
                        setStatus(message)
                        if (message.startsWith("تعذر")) setListeningUi(false)
                    } }).also { it.start(gk) }
            }
            4 -> {
                val ok = prefs.getString("openai_key", "").orEmpty()
                if (ok.isBlank()) { showApiSettings(); toast("أدخل مفتاح OpenAI أولًا"); return }
                setListeningUi(true); setStatus("جاري الاتصال بـ ChatGPT Live…")
                chatSpeech = ChatGptLiveSpeech({ t, _ -> runOnUiThread { onChatGptFragment(t) } },
                    { m -> runOnUiThread { setStatus(m); if (m.startsWith("تعذر")) setListeningUi(false) } }).also { it.start(ok) }
            }
            1, 2 -> {
                val dg = prefs.getString("deepgram_key", "").orEmpty()
                if (dg.isBlank()) { showApiSettings(); toast("أدخل مفتاح Deepgram أولًا"); return }
                setListeningUi(true); setStatus("جاري الاتصال بـ Deepgram…")
                cloudSpeech = CloudSpeech({ transcript, isFinal -> runOnUiThread {
                    val snapBefore = snapshot()
                    onTranscript(transcript, isFinal, if (mode() == 2) "deepgram+gemini" else "deepgram")
                    if (isFinal && mode() == 2 && snapshot() == snapBefore && System.currentTimeMillis() - lastUpsertMs > 4000 && transcript.isNotBlank()) {
                        setStatus("النص غير واضح؛ Gemini يحاول استخراج اللوحة…")
                        Thread {
                            val p = GeminiPlateHelper.extractPlate(prefs.getString("gemini_key", "").orEmpty(), transcript)
                            runOnUiThread {
                                if (!p.isNullOrBlank() && listening)
                                    onTranscript(p.take(3).toList().joinToString(" ") + " " + p.drop(3), true, "deepgram+gemini")
                                else if (listening) setStatus("لم يتم استخراج لوحة مؤكدة")
                            }
                        }.start()
                    }
                } }, { message -> runOnUiThread {
                    setStatus(message)
                    if (message.startsWith("تعذر")) setListeningUi(false)
                } }).also { it.start(dg) }
            }
            else -> startLocalRecognition()
        }
    }

    private fun startLocalRecognition() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { toast("خدمة التعرف على الكلام غير متاحة"); return }
        setListeningUi(true); setStatus("🎙️ جاري الاستماع")
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-SA")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        }
        try { sr?.destroy() } catch (_: Exception) {}
        sr = SpeechRecognizer.createSpeechRecognizer(this)
        sr?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { setStatus("الميكروفون جاهز") }
            override fun onBeginningOfSpeech() { setStatus("بسمعك...") }
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(error: Int) { restart(intent) }
            override fun onResults(results: Bundle?) {
                results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let { onTranscript(it, true, "voice") }
                restart(intent)
            }
            override fun onPartialResults(partialResults: Bundle?) {
                partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let { onTranscript(it, false, "voice") }
            }
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        try { sr?.startListening(intent) } catch (_: Exception) { setStatus("تعذر بدء الميكروفون") }
    }

    private fun restart(intent: Intent) {
        if (!listening) return
        window.decorView.postDelayed({
            if (listening) try { sr?.cancel(); sr?.startListening(intent) }
            catch (_: Exception) { setStatus("توقف الاستماع؛ اضغط ابدأ الاستماع مرة أخرى") }
        }, 400)
    }

    private fun stopListening() {
        window.decorView.removeCallbacks(gFlush); flushGeminiTail(); gFinalAcc = ""
        window.decorView.removeCallbacks(cFlush); flushChatTail()
        interimIds.clear(); interimStamps.clear()
        assembler.flush(RecSink("voice"))
        utterStamp = null
        setListeningUi(false)
        try { cloudSpeech?.stop() } catch (_: Exception) {}; cloudSpeech = null
        try { liveSpeech?.stop() } catch (_: Exception) {}; liveSpeech = null
        try { chatSpeech?.stop() } catch (_: Exception) {}; chatSpeech = null
        try { sr?.cancel(); sr?.destroy() } catch (_: Exception) {}
        sr = null; setStatus("متوقف")
    }

    // ---------- Location ----------
    private fun hasLoc() = ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
        ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

    private fun startLocation() {
        if (!hasLoc()) return
        try {
            val lm = getSystemService(LOCATION_SERVICE) as LocationManager
            lm.removeUpdates(locListener)
            listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER).forEach { p ->
                try { if (lm.isProviderEnabled(p)) lm.requestLocationUpdates(p, if (recording) 1000L else 5000L, 0f, locListener) } catch (_: Exception) {}
            }
        } catch (_: Exception) {}
    }

    private fun location(): Location? {
        if (!hasLoc()) return null
        return try {
            val lm = getSystemService(LOCATION_SERVICE) as LocationManager
            listOfNotNull(
                lastLoc,
                try { lm.getLastKnownLocation(LocationManager.GPS_PROVIDER) } catch (_: Exception) { null },
                try { lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER) } catch (_: Exception) { null }
            ).maxByOrNull { it.time }
        } catch (_: Exception) { null }
    }

    /** Opens the map app (GPS position) at the saved coordinates. */
    private fun openMap(lat: Double, lon: Double) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("geo:$lat,$lon?q=$lat,$lon")))
        } catch (_: Exception) {
            try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/maps/search/?api=1&query=$lat,$lon"))) }
            catch (_: Exception) { toast("لا يوجد تطبيق خرائط") }
        }
    }

    // ---------- Data ----------
    private fun currentStamp(): PlateAssembler.Stamp {
        val l = location()
        return PlateAssembler.Stamp(System.currentTimeMillis(), l?.latitude, l?.longitude)
    }
    private fun snapshot(): String = records.size.toString() + "|" + (assembler.cur?.let { it.letters + "." + it.digits } ?: "")

    /**
     * Called for every speech result. Plates are saved to the log AS SOON AS they appear in the live (interim) text,
     * each with its own time/GPS; the final text then only corrects them (same record ids), never duplicates.
     */
    private fun onTranscript(text: String, isFinal: Boolean, method: String) {
        spoken.text = (if (isFinal) "✔ " else "… ") + text
        val stamp = currentStamp()
        val creator: (Int, String?) -> PlateAssembler.Draft = { idx, pending ->
            val st = if (idx < interimStamps.size) interimStamps[idx] else { interimStamps.add(stamp); stamp }
            val id = if (idx < interimIds.size) interimIds[idx] else { val n = nextId(); interimIds.add(n); n }
            PlateAssembler.Draft("", "", pending, st, id)
        }
        val sink = RecSink(method)
        if (isFinal) {
            val created = assembler.feed(text, stamp, sink, creator)
            while (interimIds.size > created) { // plates the live text had but the final text does not
                val id = interimIds.removeAt(interimIds.size - 1); interimStamps.removeAt(interimStamps.size - 1)
                records.removeAll { it.optLong("id") == id }
                persist(); render()
            }
            interimIds.clear(); interimStamps.clear()
            assembler.cur?.let { showDraft(it.letters, it.digits) }
        } else {
            val (_, last) = assembler.preview(text, stamp, sink, creator)
            last?.let { showDraft(it.letters, it.digits) }
        }
    }

    // ---- Gemini Live final text: may arrive as small fragments or as cumulative text ----
    private var gInterim = ""
    private fun digitsOf(t: String) = PlateParser.normDigits(t).filter { it in '0'..'9' }
    private fun wordCount(t: String) = t.trim().split(Regex("\\s+")).count { it.isNotBlank() }
    /** Same spoken segment: identical digits and (almost) the same number of words. */
    private fun sameSegment(a: String, b: String) = digitsOf(a) == digitsOf(b) && abs(wordCount(a) - wordCount(b)) <= 1
    private var gFinalAcc = ""
    private var gLastFinalMs = 0L
    private var gTail = ""
    private val gFlush = Runnable { flushGeminiTail() }

    private fun onGeminiFinal(t: String) {
        val now = System.currentTimeMillis()
        if (now - gLastFinalMs > 6000) gFinalAcc = ""
        gLastFinalMs = now
        // cumulative text (repeats everything said so far): keep only the new part
        val delta = if (gFinalAcc.isNotEmpty() && t.startsWith(gFinalAcc)) { val d = t.substring(gFinalAcc.length); gFinalAcc = t; d }
                    else { gFinalAcc += t; t }
        // Gemini's final pass sometimes changes letters (e.g. ألف -> عين) that the live preview had right
        val useInterim = prefs.getBoolean("g_prefer_interim", true) && gInterim.isNotBlank() && sameSegment(delta, gInterim)
        val deltaUse = if (useInterim) gInterim else delta
        gInterim = ""
        val text = gTail + deltaUse
        window.decorView.removeCallbacks(gFlush)
        // hold back an unfinished last word so a split word (e.g. "سا" + "ع") is joined before parsing
        val cut = if (text.isNotEmpty() && !text.last().isWhitespace()) text.lastIndexOfAny(charArrayOf(' ', '\n', '\t')) + 1 else text.length
        val ready = text.substring(0, cut); gTail = text.substring(cut)
        if (ready.isNotBlank()) onTranscript(ready, true, "gemini-live")
        if (gTail.isNotEmpty()) window.decorView.postDelayed(gFlush, 700)
    }
    private fun flushGeminiTail() {
        val t = gTail; gTail = ""
        if (t.isNotBlank()) onTranscript(t, true, "gemini-live")
    }

    // ---- ChatGPT Live: text arrives as small fragments; join split words before parsing ----
    private var cTail = ""
    private val cFlush = Runnable { flushChatTail() }
    private fun onChatGptFragment(frag: String) {
        val text = cTail + frag
        window.decorView.removeCallbacks(cFlush)
        val cut = if (text.isNotEmpty() && !text.last().isWhitespace()) text.lastIndexOfAny(charArrayOf(' ', '\n', '\t')) + 1 else text.length
        val ready = text.substring(0, cut); cTail = text.substring(cut)
        if (ready.isNotBlank()) onTranscript(ready, true, "chatgpt-live")
        if (cTail.isNotEmpty()) window.decorView.postDelayed(cFlush, 500)
    }
    private fun flushChatTail() {
        val t = cTail; cTail = ""
        if (t.isNotBlank()) onTranscript(t, true, "chatgpt-live")
    }

    private inner class RecSink(val method: String) : PlateAssembler.Sink {
        override fun upsert(d: PlateAssembler.Draft, incomplete: Boolean) = upsertRecord(d, incomplete, method)
    }

    private fun nextId(): Long { idCounter = maxOf(idCounter + 1, System.currentTimeMillis()); return idCounter }

    private fun upsertRecord(d: PlateAssembler.Draft, incomplete: Boolean, method: String) {
        if (d.recordId >= 0 && deletedIds.contains(d.recordId)) return
        lastUpsertMs = System.currentTimeMillis()
        val plate = d.letters + if (d.digits.length == 3) "0" + d.digits else d.digits
        var r = if (d.recordId >= 0) records.firstOrNull { it.optLong("id") == d.recordId } else null
        if (r == null && !incomplete && d.recordId < 0) {
            val last = records.lastOrNull()
            if (last != null && last.optString("plate") == plate && d.stamp.ms - last.optLong("epoch") < 8000) {
                d.recordId = last.optLong("id"); r = last
            }
        }
        var isNew = false
        if (r == null) {
            isNew = true
            if (d.recordId < 0) d.recordId = nextId()
            r = JSONObject().apply {
                put("id", d.recordId); put("epoch", d.stamp.ms); put("timestamp", fmt.format(Date(d.stamp.ms)))
                put("lat", d.stamp.lat ?: JSONObject.NULL); put("lon", d.stamp.lon ?: JSONObject.NULL)
                put("method", method); put("recorder", nameEdit.text.toString().trim()); put("matched", false)
            }
            records.add(r)
            resolveDistrict(r)
        }
        if (!isNew && r.optString("plate") == plate && r.optString("type") == (d.type ?: "") && r.optBoolean("incomplete") == incomplete) return
        val wasMatched = r.optBoolean("matched")
        val isWanted = !incomplete && wanted.contains(plate)
        r.put("plate", plate); r.put("type", d.type ?: ""); r.put("incomplete", incomplete); r.put("matched", isWanted)
        persist(); render()
        showDraft(d.letters, d.digits)
        lastPlateView.text = plate + (d.type?.let { "  ·  $it" } ?: "")
        lastPlateView.setTextColor(if (isWanted) RED else TEAL)
        when {
            isWanted -> {
                setStatus("⚠️ $plate مطلوبة!", RED)
                showMatchCard(plate)
                if (!wasMatched) alertWanted(plate)
            }
            incomplete -> setStatus("سُجّل $plate — كمّل الباقي أو قل لوحة جديدة")
            else -> setStatus("تم تسجيل $plate" + (d.stamp.lat?.let { la -> d.stamp.lon?.let { lo -> zoneOf(la, lo) } }?.let { " — $it" } ?: ""))
        }
    }

    private fun draftFromRecord(r: JSONObject): PlateAssembler.Draft {
        val plate = r.optString("plate")
        val letters = plate.takeWhile { it in '\u0621'..'\u064A' }.take(3)
        var digits = plate.drop(letters.length)
        if (digits.length == 4 && digits.startsWith("0")) digits = digits.drop(1)
        val lat = r.optDouble("lat", Double.NaN); val lon = r.optDouble("lon", Double.NaN)
        return PlateAssembler.Draft(letters, digits, r.optString("type").ifBlank { null },
            PlateAssembler.Stamp(r.optLong("epoch"), if (lat.isFinite()) lat else null, if (lon.isFinite()) lon else null), r.optLong("id"))
    }

    /** Removes the last digit (or last letter) of the plate being built, or of the last saved plate. */
    private fun backspace() {
        var d = assembler.cur
        if (d == null) {
            val r = records.lastOrNull() ?: run { toast("لا توجد لوحة"); return }
            d = draftFromRecord(r); assembler.adopt(d)
        }
        if (d.digits.isNotEmpty()) d.digits = d.digits.dropLast(1)
        else if (d.letters.isNotEmpty()) d.letters = d.letters.dropLast(1)
        if (d.letters.isEmpty() && d.digits.isEmpty()) {
            records.removeAll { it.optLong("id") == d.recordId }
            assembler.reset(); persist(); render(); showPlate(null); lastPlateView.text = "—"; setStatus("تم مسح اللوحة")
        } else RecSink("edit").upsert(d, d.letters.length < 3 || d.digits.length < 3)
    }

    /** Fix a wrongly read plate: change the plate text and/or the vehicle type. */
    private fun editRecord(r: JSONObject) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0); layoutDirection = View.LAYOUT_DIRECTION_RTL }
        val plateEt = EditText(this).apply { hint = "اللوحة: س ر ط 7520"; setText(r.optString("plate")); setSingleLine(true) }
        val typeEt = EditText(this).apply { hint = "النوع (تاكسي، وانيت، نقل، ميكروباص، يامه)"; setText(r.optString("type")); setSingleLine(true) }
        box.addView(plateEt); box.addView(typeEt)
        AlertDialog.Builder(this).setTitle("تصحيح اللوحة").setView(box)
            .setPositiveButton("حفظ") { _, _ ->
                var got: PlateAssembler.Draft? = null
                val grab = object : PlateAssembler.Sink { override fun upsert(d: PlateAssembler.Draft, incomplete: Boolean) { got = d.copyDraft() } }
                val tmp = PlateAssembler()
                tmp.feed(plateEt.text.toString(), PlateAssembler.Stamp(r.optLong("epoch"), null, null), grab); tmp.flush(grab)
                val g = got
                if (g == null) { toast("اكتب 3 حروف وأرقام، مثل: س ر ط 7520"); return@setPositiveButton }
                val plate = g.letters + if (g.digits.length == 3) "0" + g.digits else g.digits
                val incomplete = g.letters.length < 3 || g.digits.length < 3
                r.put("plate", plate); r.put("incomplete", incomplete); r.put("matched", !incomplete && wanted.contains(plate))
                r.put("type", typeEt.text.toString().trim().ifBlank { g.type ?: "" })
                if (assembler.cur?.recordId == r.optLong("id")) assembler.adopt(draftFromRecord(r))
                persist(); render()
                if (records.lastOrNull() === r) { showPlate(plate); lastPlateView.text = plate }
            }.setNegativeButton("إلغاء", null).show()
    }

    private var lastDeleted: JSONObject? = null
    private lateinit var undoBtn: Button

    /** Deletes the whole plate immediately; "تراجع" restores it. */
    // ---------- تسجيل شارع بـ Gemini ----------
    private var mediaRec: MediaRecorder? = null
    private var recFile: File? = null
    private var recording = false
    private var recStartMs = 0L
    private val recTrack = ArrayList<DoubleArray>() // [ms, lat, lon, accuracy]
    private lateinit var streetBtn: Button
    private lateinit var recStatus: TextView
    private lateinit var pendingBtn: Button
    private val sending = HashSet<String>()
    private val sendExecutor = Executors.newSingleThreadExecutor()
    private val recTick = object : Runnable {
        override fun run() { if (recording) { updateRecTimer(); window.decorView.postDelayed(this, 1000) } }
    }

    @Suppress("DEPRECATION")
    private fun newRecorder(): MediaRecorder = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else MediaRecorder()

    private fun updateRecTimer() {
        val sec = (System.currentTimeMillis() - recStartMs) / 1000
        recStatus.setTextColor(RED); recStatus.text = String.format(Locale.US, "🔴 جاري التسجيل  %02d:%02d", sec / 60, sec % 60)
    }

    private fun startStreetRecording() {
        if (listening) { toast("أوقف الاستماع المباشر أولًا"); return }
        if (prefs.getString("gemini_key", "").isNullOrBlank()) { showApiSettings(); toast("أدخل مفتاح Gemini أولًا"); return }
        if (!hasMic()) { ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 4); return }
        try {
            val dir = File(filesDir, "pending").apply { mkdirs() }
            val f = File(dir, "rec_${System.currentTimeMillis()}.aac")
            val mr = newRecorder()
            mr.setAudioSource(MediaRecorder.AudioSource.MIC)
            mr.setOutputFormat(MediaRecorder.OutputFormat.AAC_ADTS)
            mr.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            mr.setAudioSamplingRate(16000); mr.setAudioChannels(1); mr.setAudioEncodingBitRate(48000)
            mr.setMaxDuration(30 * 60 * 1000)
            mr.setOnInfoListener { _, what, _ ->
                if (what == MediaRecorder.MEDIA_RECORDER_INFO_MAX_DURATION_REACHED) runOnUiThread { stopStreetRecording() }
            }
            mr.setOutputFile(f.absolutePath); mr.prepare(); mr.start()
            mediaRec = mr; recFile = f; recStartMs = System.currentTimeMillis()
            recTrack.clear(); recording = true
            // start point: the freshest position we already have, refined by GPS fixes arriving in the next seconds
            location()?.let { if (recStartMs - it.time < 30000) recTrack.add(doubleArrayOf(recStartMs.toDouble(), it.latitude, it.longitude, it.accuracy.toDouble())) }
            startLocation()
            streetBtn.text = "⏹ إنهاء التسجيل وإرسال"; streetBtn.background = bg(RED, 14); streetBtn.setTextColor(0xFF2A0A0A.toInt())
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            window.decorView.post(recTick)
        } catch (e: Exception) {
            recording = false; try { mediaRec?.release() } catch (_: Exception) {}; mediaRec = null
            toast("تعذر بدء التسجيل: ${e.message}")
        }
    }

    private fun stopStreetRecording() {
        if (!recording) return
        recording = false
        val endMs = System.currentTimeMillis()
        try { mediaRec?.stop() } catch (_: Exception) {}
        try { mediaRec?.release() } catch (_: Exception) {}
        mediaRec = null
        // end point: take the freshest position immediately (no waiting)
        location()?.let { if (endMs - it.time < 15000) recTrack.add(doubleArrayOf(endMs.toDouble(), it.latitude, it.longitude, it.accuracy.toDouble())) }
        startLocation()
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        streetBtn.text = "⏺ ابدأ تسجيل شارع"; streetBtn.background = bg(0xFF3A1D22.toInt(), 14); streetBtn.setTextColor(RED)
        val f = recFile; recFile = null
        if (f == null || !f.exists() || f.length() < 2000) { recStatus.setTextColor(MUTED); recStatus.text = "التسجيل قصير جدًا"; f?.delete(); return }
        val id = f.nameWithoutExtension
        val ta = JSONArray(); recTrack.forEach { p -> ta.put(JSONArray().put(p[0]).put(p[1]).put(p[2]).put(p[3])) }
        File(f.parentFile, "$id.json").writeText(JSONObject().put("id", id).put("startMs", recStartMs).put("endMs", endMs)
            .put("recorder", nameEdit.text.toString().trim()).put("track", ta).toString())
        val good = recTrack.filter { it[3] <= 100.0 }.ifEmpty { recTrack }
        val sp = bestPoint(good, recStartMs - 2000, recStartMs + 5000) ?: good.minByOrNull { it[0] }
        val ep = bestPoint(good, endMs - 5000, endMs + 1000) ?: good.maxByOrNull { it[0] }
        val locTxt = if (sp != null && ep != null) "تم أخذ موقع البداية (±${sp[3].toInt()} م) والنهاية (±${ep[3].toInt()} م)" else "لم يتوفر GPS؛ فعّل الموقع"
        recStatus.setTextColor(MUTED); recStatus.text = "$locTxt — جاري الإرسال لـ Gemini…"
        sendPending(id)
    }

    private fun bestPoint(track: List<DoubleArray>, from: Long, to: Long): DoubleArray? =
        track.filter { it[0] >= from && it[0] <= to }.minByOrNull { it[3] }

    /** Position along the recorded GPS track at a given time (linear interpolation between fixes). */
    private fun positionAt(track: List<DoubleArray>, ms: Double): Pair<Double, Double>? {
        if (track.isEmpty()) return null
        val t = track.sortedBy { it[0] }
        if (ms <= t.first()[0]) return Pair(t.first()[1], t.first()[2])
        if (ms >= t.last()[0]) return Pair(t.last()[1], t.last()[2])
        for (i in 0 until t.size - 1) {
            val a = t[i]; val b = t[i + 1]
            if (ms >= a[0] && ms <= b[0]) {
                val f = if (b[0] == a[0]) 0.0 else (ms - a[0]) / (b[0] - a[0])
                return Pair(a[1] + (b[1] - a[1]) * f, a[2] + (b[2] - a[2]) * f)
            }
        }
        return Pair(t.last()[1], t.last()[2])
    }

    private fun pendingIds(): List<String> =
        File(filesDir, "pending").listFiles { f -> f.extension == "json" }?.map { it.nameWithoutExtension }?.sorted().orEmpty()

    private fun refreshPending() {
        if (!::pendingBtn.isInitialized) return
        val n = pendingIds().size
        pendingBtn.visibility = if (n > 0 && !recording) View.VISIBLE else View.GONE
        pendingBtn.text = "📤 إرسال التسجيلات المعلّقة ($n)"
    }

    private fun sendPending(id: String) {
        if (!sending.add(id)) return
        val key = prefs.getString("gemini_key", "").orEmpty()
        if (key.isBlank()) { sending.remove(id); showApiSettings(); toast("أدخل مفتاح Gemini أولًا"); return }
        recStatus.setTextColor(MUTED); recStatus.text = "جاري إرسال التسجيل لـ Gemini…"
        sendExecutor.execute {
            val dir = File(filesDir, "pending")
            val aac = File(dir, "$id.aac"); val metaF = File(dir, "$id.json")
            try {
                val meta = JSONObject(metaF.readText())
                val res = GeminiStreetTranscriber.transcribe(key, aac)
                runOnUiThread { applyStreetResult(meta, res); aac.delete(); metaF.delete(); sending.remove(id); refreshPending() }
            } catch (e: Exception) {
                runOnUiThread {
                    sending.remove(id); refreshPending()
                    recStatus.setTextColor(RED)
                    recStatus.text = "تعذر الإرسال: ${e.message} — التسجيل محفوظ على الهاتف، اضغط إرسال المعلّقة لاحقًا"
                }
            }
        }
    }

    private fun applyStreetResult(meta: JSONObject, res: GeminiStreetTranscriber.Result) {
        val startMs = meta.getLong("startMs"); val endMs = meta.getLong("endMs")
        val ta = meta.optJSONArray("track") ?: JSONArray()
        val track = ArrayList<DoubleArray>()
        for (i in 0 until ta.length()) { val p = ta.getJSONArray(i); track.add(doubleArrayOf(p.getDouble(0), p.getDouble(1), p.getDouble(2), p.getDouble(3))) }
        val good = track.filter { it[3] <= 100.0 }.ifEmpty { track }
        val sp = bestPoint(good, startMs - 2000, startMs + 5000) ?: good.minByOrNull { it[0] }
        val ep = bestPoint(good, endMs - 5000, endMs + 1000) ?: good.maxByOrNull { it[0] }
        val recorder = meta.optString("recorder")
        val items = res.items; val n = items.size
        var matchedCount = 0; var lastMatched: String? = null
        items.forEachIndexed { i, item ->
            val frac = if (n > 1) i.toDouble() / (n - 1) else 0.0
            val rawMs = if (item.t != null) startMs + (item.t * 1000).toLong() else startMs + ((endMs - startMs) * frac).toLong()
            val ms = rawMs.coerceIn(startMs, endMs)
            val pos = positionAt(good, ms.toDouble())
            val isWanted = !item.unclear && wanted.contains(item.plate)
            val r = JSONObject().apply {
                put("id", nextId()); put("epoch", ms); put("timestamp", fmt.format(Date(ms)))
                put("lat", pos?.first ?: JSONObject.NULL); put("lon", pos?.second ?: JSONObject.NULL)
                put("method", "gemini-recording"); put("recorder", recorder)
                put("plate", item.plate); put("type", item.type); put("street", item.street); put("pin", item.pin)
                put("incomplete", false); put("unclear", item.unclear); put("matched", isWanted)
                if (sp != null) { put("startLat", sp[1]); put("startLon", sp[2]) }
                if (ep != null) { put("endLat", ep[1]); put("endLon", ep[2]) }
            }
            records.add(r); resolveDistrict(r)
            if (isWanted) { matchedCount++; lastMatched = item.plate }
        }
        records.sortBy { it.optLong("epoch") }
        persist(); render()
        records.lastOrNull()?.let { showPlate(it.optString("plate")); lastPlateView.text = it.optString("plate") }
        lastMatched?.let { showMatchCard(it); alertWanted(it) }
        recStatus.setTextColor(TEAL)
        recStatus.text = if (items.isEmpty()) "لم يجد Gemini لوحات في التسجيل"
            else "تم تفريغ ${items.size} لوحة" + (if (matchedCount > 0) " — منها $matchedCount مطلوبة ⚠️" else "") + " ✓"
        if (res.notes.isNotBlank()) AlertDialog.Builder(this).setTitle("ملاحظات التفريغ").setMessage(res.notes).setPositiveButton("تمام", null).show()
    }

    /** Street (spoken, or taken from GPS) followed by the pin, in one cell. */
    private fun streetLabel(r: JSONObject): String =
        listOfNotNull(r.optString("street").takeIf { it.isNotBlank() }, r.optString("pin").takeIf { it.isNotBlank() }?.let { "دبوس $it" }).joinToString(" ")

    private fun startEndCell(r: JSONObject, k: String): XlsxWriter.Cell {
        val la = r.optDouble("${k}Lat", Double.NaN); val lo = r.optDouble("${k}Lon", Double.NaN)
        return if (la.isFinite() && lo.isFinite())
            XlsxWriter.Cell(if (k == "start") "📍 بداية الشارع" else "📍 نهاية الشارع", "https://maps.google.com/?q=$la,$lo")
        else XlsxWriter.Cell("")
    }

    // ---------- Wanted details ----------
    private fun infoLines(plate: String): List<String> {
        val rows = wantedInfo[plate] ?: return emptyList()
        val out = mutableListOf<String>()
        rows.forEachIndexed { i, row ->
            if (rows.size > 1) out.add("— سجل ${i + 1} —")
            row.forEach { out.add("${it.first}: ${it.second}") }
        }
        return out
    }
    private fun infoText(plate: String) = infoLines(plate).joinToString("\n").ifBlank { "لا توجد بيانات إضافية في الملف" }

    private fun showMatchCard(plate: String) {
        matchTitle.text = "⚠️ لوحة مطلوبة: $plate"
        matchBody.text = infoText(plate)
        matchCard.visibility = View.VISIBLE
    }
    private fun showMatchDialog(plate: String) {
        val tvBody = TextView(this).apply { text = infoText(plate); textSize = 16f; setPadding(dp(20), dp(12), dp(20), dp(8)); setTextIsSelectable(true); layoutDirection = View.LAYOUT_DIRECTION_RTL }
        AlertDialog.Builder(this).setTitle("بيانات المطلوب: $plate").setView(ScrollView(this).apply { addView(tvBody) })
            .setPositiveButton("تمام", null).show()
    }

    // ---------- Neighbourhood (الحي) ----------
    private val addrCache = java.util.concurrent.ConcurrentHashMap<String, Pair<String?, String?>>()

    /** Fills the neighbourhood (and, for recorded streets with no spoken name, the street name) from the GPS position. */
    private fun resolveDistrict(r: JSONObject) {
        val lat = r.optDouble("lat", Double.NaN); val lon = r.optDouble("lon", Double.NaN)
        if (!lat.isFinite() || !lon.isFinite()) return
        val needDistrict = r.optString("district").isBlank()
        val needStreet = r.optString("street").isBlank() && r.optString("method") == "gemini-recording"
        if (!needDistrict && !needStreet) return
        val dKey = String.format(Locale.US, "%.3f,%.3f", lat, lon)
        if (needDistrict && !needStreet) { districtCache[dKey]?.let { r.put("district", it); return } }
        val aKey = "${Math.round(lat / 0.0005)},${Math.round(lon / 0.0005)}" // ~55 m cells
        geoExecutor.execute {
            val addr = addrCache[aKey] ?: geocodeFull(lat, lon).also { if (it.first != null || it.second != null) addrCache[aKey] = it }
            runOnUiThread {
                var changed = false
                if (needDistrict) (addr.first ?: districtCache[dKey])?.let { districtCache[dKey] = it; r.put("district", it); changed = true }
                if (needStreet) addr.second?.let { r.put("street", it); changed = true }
                if (changed) { persist(); render() }
            }
        }
    }

    /** (neighbourhood, street) for a GPS position: Google first, then OpenStreetMap for whatever is missing. */
    private fun geocodeFull(lat: Double, lon: Double): Pair<String?, String?> {
        var district: String? = null; var street: String? = null; var fallback: String? = null
        try {
            if (Geocoder.isPresent()) {
                @Suppress("DEPRECATION")
                val a = Geocoder(this, Locale("ar")).getFromLocation(lat, lon, 1)?.firstOrNull()
                if (a != null) {
                    district = a.subLocality?.takeIf { it.isNotBlank() }
                    street = a.thoroughfare?.takeIf { it.isNotBlank() }
                    fallback = a.locality ?: a.subAdminArea
                }
            }
        } catch (_: Exception) {}
        if (district == null || street == null) {
            try {
                Thread.sleep(1100) // OpenStreetMap policy: max 1 request per second
                val req = Request.Builder()
                    .url("https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat=$lat&lon=$lon&zoom=17&addressdetails=1&accept-language=ar")
                    .header("User-Agent", "PlateHunterApp/1.0").build()
                http.newCall(req).execute().use { resp ->
                    if (resp.isSuccessful) {
                        val addr = JSONObject(resp.body?.string().orEmpty()).optJSONObject("address")
                        if (addr != null) {
                            if (district == null) {
                                for (k in listOf("neighbourhood", "suburb", "quarter", "city_district", "residential", "village", "town", "city")) {
                                    val v = addr.optString(k); if (v.isNotBlank()) { district = v; break }
                                }
                            }
                            if (street == null) street = addr.optString("road").takeIf { it.isNotBlank() }
                        }
                    }
                }
            } catch (_: Exception) {}
        }
        return Pair(district ?: fallback, street)
    }

    private fun geocodeDistrict(lat: Double, lon: Double): String? = geocodeFull(lat, lon).first

    /** Vibrates, sounds an alarm tone, then says "مطلوبة" (once per plate). */
    private fun alertWanted(plate: String) {
        try { (getSystemService(VIBRATOR_SERVICE) as Vibrator).vibrate(VibrationEffect.createOneShot(800, VibrationEffect.DEFAULT_AMPLITUDE)) } catch (_: Exception) {}
        if (!prefs.getBoolean("alert_sound", true)) return
        try {
            val tg = ToneGenerator(AudioManager.STREAM_ALARM, 100)
            tg.startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, 900)
            window.decorView.postDelayed({ try { tg.release() } catch (_: Exception) {} }, 1500)
        } catch (_: Exception) {}
        window.decorView.postDelayed({
            if (ttsReady) tts?.speak("مطلوبة", TextToSpeech.QUEUE_FLUSH, null, "wanted-$plate")
        }, 1000)
    }

    private fun deleteRecord(r: JSONObject) {
        val id = r.optLong("id")
        deletedIds.add(id)
        records.removeAll { it.optLong("id") == id }
        assembler.dropRecord(id)
        lastDeleted = r
        undoBtn.text = "↩ تراجع عن حذف ${r.optString("plate")}"; undoBtn.visibility = View.VISIBLE
        persist(); render(); setStatus("تم حذف ${r.optString("plate")}")
        records.lastOrNull().let { if (it == null) { showPlate(null); lastPlateView.text = "—" } }
    }

    private fun load() {
        try {
            val f = File(filesDir, "records.json")
            if (f.exists()) { val a = JSONArray(f.readText()); for (i in 0 until a.length()) records.add(a.getJSONObject(i)) }
        } catch (_: Exception) {}
        try {
            val w = File(filesDir, "wanted.txt")
            if (w.exists()) w.forEachLine { line ->
                if (line.isBlank()) return@forEachLine
                val parts = line.split('\t', limit = 2)
                val plate = parts[0].trim(); wanted.add(plate)
                if (parts.size == 2 && parts[1].isNotBlank()) {
                    val fields = parts[1].split('\u0001').mapNotNull { f -> f.split('\u0002', limit = 2).let { if (it.size == 2) it[0] to it[1] else null } }
                    if (fields.isNotEmpty()) wantedInfo.getOrPut(plate) { mutableListOf() }.add(fields)
                }
            }
        } catch (_: Exception) {}
        records.forEach { if (it.optLong("id") == 0L) it.put("id", nextId()) }
        persist()
        records.lastOrNull()?.let { showPlate(it.optString("plate")); lastPlateView.text = it.optString("plate") }
    }
    private fun persist() {
        try { val a = JSONArray(); records.forEach { a.put(it) }; File(filesDir, "records.json").writeText(a.toString()) }
        catch (_: Exception) { toast("تعذر حفظ السجلات") }
    }
    private fun saveWanted() {
        try {
            fun clean(t: String) = t.replace('\t', ' ').replace('\n', ' ').replace('\r', ' ').replace('\u0001', ' ').replace('\u0002', ' ')
            File(filesDir, "wanted.txt").bufferedWriter().use { w ->
                for (p in wanted) {
                    val rows = wantedInfo[p]
                    if (rows.isNullOrEmpty()) { w.write(p); w.newLine() }
                    else rows.forEach { row ->
                        w.write(p); w.write("\t")
                        w.write(row.joinToString("\u0001") { clean(it.first) + "\u0002" + clean(it.second) }); w.newLine()
                    }
                }
            }
        } catch (_: Exception) { toast("تعذر حفظ قائمة المطلوبين") }
    }

    private fun render() {
        if (!::recordsBox.isInitialized) return
        platesCount.text = records.size.toString()
        wantedCount.text = records.count { it.optBoolean("matched") }.toString()
        setTitle(wantedHeader, "قائمة المطلوبين (${wanted.size})")
        recordsBox.removeAllViews()
        records.takeLast(100).reversed().forEach { r ->
            val matched = r.optBoolean("matched"); val incomplete = r.optBoolean("incomplete")
            val lat = r.optDouble("lat", Double.NaN); val lon = r.optDouble("lon", Double.NaN)
            val located = lat.isFinite() && lon.isFinite()
            val unclear = r.optBoolean("unclear")
            val st = if (matched) "مطلوبة" else if (incomplete) "ناقصة" else if (unclear) "غير واضحة" else "عادية"
            val stColor = if (matched) RED else if (incomplete || unclear) 0xFFE0B341.toInt() else MUTED
            recordsBox.addView(row(
                r.optString("plate"), r.optString("type").ifBlank { "—" }, st,
                r.optString("timestamp").substringAfter(' '),
                if (located) locLabel(r) else "—",
                false, stColor, if (located) ({ openMap(lat, lon) }) else null, { deleteRecord(r) }, { editRecord(r) },
                if (matched) ({ showMatchDialog(r.optString("plate")) }) else null
            ).apply { background = bg(if (matched) 0xFF2A1B20.toInt() else CARD, 10) })
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 10 && resultCode == RESULT_OK) {
            try {
                val uri = data?.data ?: return
                val table = SpreadsheetReader.readWanted(contentResolver, uri)
                wanted.clear(); wantedInfo.clear()
                for (row in table.rows) {
                    val p = PlateParser.normalize(row.getOrNull(table.plateCol).orEmpty())
                    if (p.isBlank()) continue
                    wanted.add(p)
                    val fields = table.headers.mapIndexedNotNull { i, h ->
                        if (i == table.plateCol) null else row.getOrNull(i)?.trim()?.takeIf { it.isNotBlank() }?.let { h to it }
                    }
                    if (fields.isNotEmpty()) wantedInfo.getOrPut(p) { mutableListOf() }.add(fields)
                }
                saveWanted()
                records.forEach { it.put("matched", wanted.contains(it.optString("plate"))) }
                persist(); render(); toast("تم استيراد ${wanted.size} لوحة ومطابقة السجلات")
            } catch (e: Exception) {
                toast(e.message ?: "تعذر قراءة الملف؛ جرّب XLSX أو CSV")
            }
        }
    }

    /** Fills in any missing neighbourhood (الحي) first, then writes the Excel file. */
    private fun export() {
        if (records.isEmpty()) { toast("السجل فارغ"); return }
        val missing = records.filter { r ->
            r.optString("district").isBlank() && r.optDouble("lat", Double.NaN).isFinite() && r.optDouble("lon", Double.NaN).isFinite()
        }
        if (missing.isEmpty()) { buildAndShare(); return }
        setStatus("جاري تحديد الأحياء قبل التصدير (0/${missing.size})…")
        Thread {
            missing.forEachIndexed { i, r ->
                val lat = r.optDouble("lat"); val lon = r.optDouble("lon")
                val key = String.format(Locale.US, "%.3f,%.3f", lat, lon)
                val name = districtCache[key] ?: geocodeDistrict(lat, lon)?.also { districtCache[key] = it }
                if (!name.isNullOrBlank()) r.put("district", name)
                runOnUiThread { setStatus("جاري تحديد الأحياء قبل التصدير (${i + 1}/${missing.size})…") }
            }
            runOnUiThread { persist(); render(); buildAndShare() }
        }.start()
    }

    private fun buildAndShare() {
        try {
            val rows = records.map { r ->
                val lat = r.optDouble("lat", Double.NaN); val lon = r.optDouble("lon", Double.NaN)
                val ok = lat.isFinite() && lon.isFinite()
                listOf(
                    XlsxWriter.Cell(r.optString("plate")),
                    // الموقع: اسم الحي ظاهر، والضغط عليه يفتح الموقع بالضبط على الخريطة
                    if (ok) XlsxWriter.Cell(listOfNotNull(zoneOf(lat, lon), r.optString("district").takeIf { it.isNotBlank() }).joinToString(" - ").ifBlank { "فتح الموقع" }, "https://maps.google.com/?q=$lat,$lon")
                    else XlsxWriter.Cell(r.optString("district")),
                    XlsxWriter.Cell(streetLabel(r)),
                    XlsxWriter.Cell(r.optString("type")),
                    XlsxWriter.Cell(r.optString("timestamp")),
                    XlsxWriter.Cell(if (r.optBoolean("matched")) "مطلوبة" else if (r.optBoolean("incomplete")) "ناقصة" else if (r.optBoolean("unclear")) "غير واضحة" else "عادية"),
                    XlsxWriter.Cell(if (r.optBoolean("matched")) infoLines(r.optString("plate")).joinToString(" | ") else ""),
                    XlsxWriter.Cell(r.optString("recorder")),
                    XlsxWriter.Cell(if (ok) String.format(Locale.US, "%.6f, %.6f", lat, lon) else ""),
                    XlsxWriter.Cell(if (ok) zoneOf(lat, lon).orEmpty() else ""),
                    startEndCell(r, "start"), startEndCell(r, "end")
                )
            }
            val name = "plates_" + SimpleDateFormat("yyyy-MM-dd_HHmm", Locale.US).format(Date()) + ".xlsx"
            val f = File(cacheDir, name)
            XlsxWriter.write(f, "السجل", listOf("اللوحة", "الموقع", "الشارع", "النوع", "الوقت", "الحالة", "بيانات المطلوب", "المسجِّل", "الإحداثيات", "المربع", "بداية الشارع", "نهاية الشارع"),
                setOf(0, 1, 2, 3), listOf(16, 26, 22, 14, 20, 12, 50, 16, 24, 16, 18, 18), rows)
            AlertDialog.Builder(this).setTitle("ملف Excel جاهز").setMessage(name)
                .setPositiveButton("💾 حفظ في التنزيلات") { _, _ -> saveToDownloads(f, name) }
                .setNeutralButton("📤 مشاركة") { _, _ ->
                    val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", f)
                    startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
                        type = XLSX_MIME
                        putExtra(Intent.EXTRA_STREAM, uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }, "تصدير ملف Excel"))
                }
                .setNegativeButton("إلغاء", null).show()
        } catch (e: Exception) { toast("تعذر التصدير: ${e.message}") }
    }

    private val XLSX_MIME = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"

    /** Saves the file with its real name into Downloads/PlateHunter (no WhatsApp "DOC-…" renaming, editable copy). */
    private fun saveToDownloads(f: File, name: String) {
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, name); put(MediaStore.Downloads.MIME_TYPE, XLSX_MIME)
                    put(MediaStore.Downloads.RELATIVE_PATH, "Download/PlateHunter")
                }
                val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: throw Exception("تعذر إنشاء الملف")
                contentResolver.openOutputStream(uri)?.use { out -> f.inputStream().use { it.copyTo(out) } }
                toast("تم الحفظ في: التنزيلات ← PlateHunter ← $name")
            } else {
                val dir = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: filesDir
                f.copyTo(File(dir, name), overwrite = true)
                toast("تم الحفظ في: ${dir.absolutePath}")
            }
        } catch (e: Exception) { toast("تعذر الحفظ: ${e.message}") }
    }

    private fun showApiSettings() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0) }
        val deepgram = EditText(this).apply { hint = "Deepgram API Key"; inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD; setText(prefs.getString("deepgram_key", "")) }
        val gemini = EditText(this).apply { hint = "Gemini API Key (لوضع Gemini Live والاحتياطي)"; inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD; setText(prefs.getString("gemini_key", "")) }
        box.addView(TextView(this).apply { text = "للاستخدام الشخصي فقط: حفظ المفتاح داخل الهاتف ليس حماية كاملة. لا تنشر APK بمفاتيحك."; textSize = 13f })
        val openai = EditText(this).apply { hint = "OpenAI API Key (لوضع ChatGPT Live)"; inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD; setText(prefs.getString("openai_key", "")) }
        box.addView(deepgram); box.addView(gemini); box.addView(openai)
        AlertDialog.Builder(this).setTitle("إعداد مفاتيح API").setView(box)
            .setPositiveButton("حفظ") { _, _ -> prefs.edit().putString("deepgram_key", deepgram.text.toString().trim()).putString("gemini_key", gemini.text.toString().trim()).putString("openai_key", openai.text.toString().trim()).apply(); toast("تم حفظ الإعدادات على هذا الهاتف") }
            .setNegativeButton("إلغاء", null).show()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    override fun onDestroy() {
        listening = false
        try { cloudSpeech?.stop() } catch (_: Exception) {}
        try { liveSpeech?.stop() } catch (_: Exception) {}
        try { chatSpeech?.stop() } catch (_: Exception) {}
        try { sr?.destroy() } catch (_: Exception) {}
        try { tts?.stop(); tts?.shutdown() } catch (_: Exception) {}
        try { mediaRec?.release() } catch (_: Exception) {}
        try { (getSystemService(LOCATION_SERVICE) as LocationManager).removeUpdates(locListener) } catch (_: Exception) {}
        super.onDestroy()
    }
}
